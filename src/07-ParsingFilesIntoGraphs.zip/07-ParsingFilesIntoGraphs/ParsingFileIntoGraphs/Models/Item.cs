namespace ParsingFilesIntoGraphs
{
    public class Item
    {
        public string StartCity {get;set;}
        public string EndCity {get;set;}
        public decimal Distance {get;set;}
        public int TimeInMinutes {get;set;}
    }
}