﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ParsingFilesIntoGraphs
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
